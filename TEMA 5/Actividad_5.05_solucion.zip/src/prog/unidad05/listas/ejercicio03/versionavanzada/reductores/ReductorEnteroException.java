package prog.unidad05.listas.ejercicio03.versionavanzada.reductores;

public class ReductorEnteroException extends RuntimeException {

  public ReductorEnteroException(String msg) {
    super(msg);
  }

}
