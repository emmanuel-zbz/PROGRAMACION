package prog.unidad05.listas.ejercicio08;

import java.util.ArrayList;
import java.util.List;

/**
 * Alumno del centro con calificaciones
 */
public class Alumno {

  // Atributos
  // DNI (no debe ser null y debe constar de 9 caracteres)
  private String dni;
  // Nombre (no debe ser vacío ni null)
  private String nombre;
  // Edad (debe ser positiva)
  private int edad;
  // Lista con las calificaciones
  List<Double> calificaciones;
  
  /**
   * Constructor
   * @param dni DNI del alumno. No puede ser null y debe constar de 9 caracteres
   * @param nombre Nombre del alumno. No puede ser null ni vacío
   * @param edad Edad del alumno. Debe ser positiva
   * @throws NullPointerException Si dni o nombre son null
   * @throws IllegalArgumentException Si dni no tiene 9 caracteres o nombre está vacío o la edad es
   *   menor o igual que cero
   */
  public Alumno(String dni, String nombre, int edad) {
    // Si los parámetros son correctos
    if (dni.length() == 9 && !nombre.isEmpty() && edad >= 0) {
      // Los almacena
      this.dni = dni;
      this.nombre = nombre;
      this.edad = edad;
      // Las calificaciones inicialmente están vacías
      calificaciones = new ArrayList<>();
    } else {
      // Algún parámetro es incorrecto
      // Lanza excepción
      throw new IllegalArgumentException();
    }
  }

  /**
   * Obtiene el DNI
   * @return DNI del alumno
   */
  public String getDni() {
    return dni;
  }

  /**
   * Obtiene el nombre
   * @return Nombre del alumno
   */
  public String getNombre() {
    return nombre;
  }

  /**
   * Obtiene la edad
   * @return Edad del alumno
   */
  public int getEdad() {
    return edad;
  }
  
  /**
   * Obtiene una representación en formato cadena de la información del alumno en formato:<br>
   * <code>DNI: dni, Nombre: nombre, Edad: edad</code>
   * @return Cadena con la información del alumno
   */
  public String toString() {
    return "DNI: " + dni + ", Nombre: " + nombre + ", Edad: " + edad;
  }

  /**
   * Añade una calificación a un alumno
   * @param calificacion Calificación a añadir. Debe valer entre 0 y 10, ambos inclusive
   * @throws IllegalArgumentException Si la calificación no es válida
   */
  public void addCalificacion(double calificacion) {
    // Si la calificación es válida
    if (calificacion >= 0 && calificacion <= 10) {
      // Se añade
      calificaciones.add(calificacion);
    } else {
      // Si no es válida se lanza excepción
      throw new IllegalArgumentException("Calificación no válida. Debe valer entre 0 y 10, ambas incluidas");
    }
  }
  
  /**
   * Obtiene las calificaciones de un alumno
   * @return Calificaciones del alumno. Puede ser vacía
   */
  public List<Double> getCalificaciones() {
    return calificaciones;
  }
}
